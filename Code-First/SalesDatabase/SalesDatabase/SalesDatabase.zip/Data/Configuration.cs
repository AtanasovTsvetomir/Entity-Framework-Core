﻿namespace SalesDatabase.Data
{
    static class Configuration
    {
        internal static string ConnectionString = @"Server=DESKTOP-M8SK6SD\SQLEXPRESS01;Database=SalesDatabase;Integrated Security=true;";
    }
}
