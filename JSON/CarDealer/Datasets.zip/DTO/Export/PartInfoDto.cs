﻿namespace CarDealer.DTO.Export
{
    public class PartInfoDto
    {
        public string Name { get; set; }

        public decimal Price { get; set; }
    }
}
